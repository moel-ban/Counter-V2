package com.motkine.numbercounter;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final long LIMIT = 8L * 60L * 60L * 1000L;
    private SharedPreferences prefs;
    private long total=0, startedAt=0, endedAt=0, tips=0, amountsTotal=0;
    private int entries=0, camel=0, winston=0, marlboro=0, gauloises=0;
    private boolean active=false;
    private final ArrayList<String> amountHistory = new ArrayList<>();
    private TextView totalView,statusView,timerView,entriesView,tipsView,amountsView,
            camelView,winstonView,marlboroView,gauloisesView,historyView;
    private EditText numberInput,tipInput,amountInput;
    private Button startButton,addButton,stopButton;
    private final Handler handler=new Handler();
    private final Runnable ticker=new Runnable(){@Override public void run(){checkExpiry();refresh();handler.postDelayed(this,1000);}};

    @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("counter",MODE_PRIVATE);load();buildUi();checkExpiry();refresh();}
    private void load(){
        total=prefs.getLong("total",0);startedAt=prefs.getLong("started",0);endedAt=prefs.getLong("ended",0);
        entries=prefs.getInt("entries",0);active=prefs.getBoolean("active",false);tips=prefs.getLong("tips",0);
        amountsTotal=prefs.getLong("amountsTotal",0);camel=prefs.getInt("camel",0);winston=prefs.getInt("winston",0);
        marlboro=prefs.getInt("marlboro",0);gauloises=prefs.getInt("gauloises",0);
        try{JSONArray a=new JSONArray(prefs.getString("amountHistory","[]"));for(int i=0;i<a.length();i++)amountHistory.add(a.getString(i));}catch(Exception ignored){}
    }
    private void save(){
        JSONArray a=new JSONArray();for(String s:amountHistory)a.put(s);
        prefs.edit().putLong("total",total).putLong("started",startedAt).putLong("ended",endedAt)
            .putInt("entries",entries).putBoolean("active",active).putLong("tips",tips)
            .putLong("amountsTotal",amountsTotal).putInt("camel",camel).putInt("winston",winston)
            .putInt("marlboro",marlboro).putInt("gauloises",gauloises).putString("amountHistory",a.toString()).apply();
    }
    private void checkExpiry(){if(active && System.currentTimeMillis()>=startedAt+LIMIT){active=false;endedAt=startedAt+LIMIT;save();if(statusView!=null)Toast.makeText(this,"8 hours completed. Session finished.",Toast.LENGTH_LONG).show();}}
    private void buildUi(){
        ScrollView scroll=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(22,28,22,28);root.setBackgroundColor(0xFFF4F6F8);scroll.addView(root);
        TextView title=txt("NUMBER COUNTER",23,0xFF182030,true);title.setGravity(Gravity.CENTER);root.addView(title);
        TextView sub=txt("8-hour session • Version 2",13,Color.GRAY,false);sub.setGravity(Gravity.CENTER);root.addView(sub);space(root,20);
        totalView=txt("0",46,0xFF16865B,true);totalView.setGravity(Gravity.CENTER);root.addView(totalView);
        TextView label=txt("MAIN TOTAL",12,Color.GRAY,true);label.setGravity(Gravity.CENTER);root.addView(label);
        statusView=txt("",14,0xFF16865B,true);statusView.setGravity(Gravity.CENTER);space(root,8);root.addView(statusView);
        timerView=txt("",14,Color.DKGRAY,false);timerView.setGravity(Gravity.CENTER);root.addView(timerView);
        entriesView=txt("",12,Color.GRAY,false);entriesView.setGravity(Gravity.CENTER);root.addView(entriesView);
        startButton=button("START SESSION",0xFF16865B);root.addView(startButton);
        startButton.setOnClickListener(v->{if(!active){resetData();startedAt=System.currentTimeMillis();endedAt=0;active=true;save();refresh();}});
        section(root,"MAIN COUNTER");
        numberInput=input("Enter a number");numberInput.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_SIGNED);root.addView(numberInput);
        addButton=button("ADD NUMBER",0xFF263B59);root.addView(addButton);addButton.setOnClickListener(v->addNumber());
        section(root,"POURBOIRES");
        tipInput=input("Enter tip amount (DH)");tipInput.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);root.addView(tipInput);
        Button tipButton=button("ADD POURBOIRE",0xFF8B5CF6);root.addView(tipButton);tipButton.setOnClickListener(v->addMoney(tipInput,true));
        tipsView=txt("Pourboires total: 0 DH",16,0xFF6D45C5,true);root.addView(tipsView);
        section(root,"GARRO SOLD • +1 PER TAP");
        addBrand(root,"Camel",()->camel++,0);
        addBrand(root,"Winston",()->winston++,1);
        addBrand(root,"Marlboro",()->marlboro++,2);
        addBrand(root,"Gauloises",()->gauloises++,3);
        section(root,"AMOUNT HISTORY");
        amountInput=input("Enter amount (DH)");amountInput.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);root.addView(amountInput);
        Button amountButton=button("ADD AMOUNT TO HISTORY",0xFF0F766E);root.addView(amountButton);amountButton.setOnClickListener(v->addMoney(amountInput,false));
        amountsView=txt("Amounts total: 0 DH",16,0xFF0F766E,true);root.addView(amountsView);
        historyView=txt("No amounts yet",13,Color.DKGRAY,false);root.addView(historyView);
        section(root,"SESSION");
        stopButton=button("STOP & SHOW REPORT",0xFFC44848);root.addView(stopButton);
        stopButton.setOnClickListener(v->{if(active){checkExpiry();if(active){active=false;endedAt=System.currentTimeMillis();save();refresh();showReport();}}});
        Button reset=button("RESET / NEW SESSION",0xFF777777);root.addView(reset);
        reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Reset session?").setMessage("All current session data will be cleared.").setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{active=false;resetData();startedAt=0;endedAt=0;save();refresh();}).show());
        setContentView(scroll);
    }
    private void addBrand(LinearLayout root,String name,Runnable increment,int which){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(12,4,12,4);row.setBackgroundColor(Color.WHITE);
        TextView n=txt(name,17,0xFF202938,true);row.addView(n,new LinearLayout.LayoutParams(0,-2,1));
        TextView count=txt("0",20,0xFF202938,true);row.addView(count);Button plus=button("+",0xFF263B59);
        row.addView(plus,new LinearLayout.LayoutParams(90,-2));root.addView(row);space(root,6);
        plus.setOnClickListener(v->{if(!requireActive())return;increment.run();save();refresh();});
        if(which==0)camelView=count;else if(which==1)winstonView=count;else if(which==2)marlboroView=count;else gauloisesView=count;
    }
    private void addNumber(){if(!requireActive())return;String s=numberInput.getText().toString().trim();if(s.isEmpty()){numberInput.setError("Enter a number");return;}try{total+=Long.parseLong(s);entries++;numberInput.setText("");save();refresh();}catch(Exception e){numberInput.setError("Invalid number");}}
    private void addMoney(EditText field,boolean isTip){
        if(!requireActive())return;String s=field.getText().toString().trim();if(s.isEmpty()){field.setError("Enter an amount");return;}
        try{double value=Double.parseDouble(s.replace(',','.'));if(value<=0||value>100000000){field.setError("Enter a valid amount");return;}
            long cents=Math.round(value*100);if(isTip)tips+=cents;else{amountsTotal+=cents;String record=String.format(Locale.getDefault(),"%.2f DH  •  %s",value,new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));amountHistory.add(0,record);}
            field.setText("");save();refresh();
        }catch(Exception e){field.setError("Invalid amount");}
    }
    private boolean requireActive(){checkExpiry();if(!active){Toast.makeText(this,"Press START first",Toast.LENGTH_SHORT).show();refresh();return false;}return true;}
    private void resetData(){total=0;entries=0;tips=0;amountsTotal=0;camel=0;winston=0;marlboro=0;gauloises=0;amountHistory.clear();}
    private void showReport(){
        String report="Main total: "+total+"\nNumbers added: "+entries+"\nPourboires: "+money(tips)+" DH\nAmounts history total: "+money(amountsTotal)+" DH\n\nGarro sold:\nCamel: "+camel+"\nWinston: "+winston+"\nMarlboro: "+marlboro+"\nGauloises: "+gauloises+"\n\nDuration: "+duration();
        new AlertDialog.Builder(this).setTitle("Final session report").setMessage(report).setPositiveButton("OK",null).show();
    }
    private String duration(){if(startedAt==0)return "00:00:00";long end=endedAt>0?endedAt:System.currentTimeMillis();long s=Math.max(0,(end-startedAt)/1000);return String.format(Locale.getDefault(),"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60);}
    private String money(long cents){return String.format(Locale.getDefault(),"%.2f",cents/100.0);}
    private void refresh(){
        if(totalView==null)return;totalView.setText(String.valueOf(total));statusView.setText(active?"● SESSION ACTIVE":(endedAt>0?"SESSION FINISHED":"NOT STARTED"));
        timerView.setText(active?"Elapsed: "+duration()+" / 08:00:00":"Duration: "+duration());entriesView.setText("Numbers added: "+entries);
        startButton.setEnabled(!active);addButton.setEnabled(active);stopButton.setEnabled(active);
        tipsView.setText("Pourboires total: "+money(tips)+" DH");amountsView.setText("Amounts total: "+money(amountsTotal)+" DH");
        camelView.setText(""+camel);winstonView.setText(""+winston);marlboroView.setText(""+marlboro);gauloisesView.setText(""+gauloises);
        StringBuilder h=new StringBuilder();for(String s:amountHistory)h.append("• ").append(s).append('\n');historyView.setText(h.length()==0?"No amounts yet":h.toString());
    }
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(4,8,4,8);return t;}
    private EditText input(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(16);e.setHint(hint);return e;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));return b;}
    private void section(LinearLayout root,String s){space(root,18);TextView t=txt(s,16,0xFF182030,true);root.addView(t);}
    private void space(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,h));}
    @Override protected void onResume(){super.onResume();handler.post(ticker);}
    @Override protected void onPause(){super.onPause();handler.removeCallbacks(ticker);}
}
